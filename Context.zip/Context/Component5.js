import React, { useContext } from "react";
import UserContext from "./UserContext";

function Component5() {
    const user = useContext(UserContext);

  return (
    <>
       
      <h2>{user}</h2>
    </>
  );
}

export default Component5;
