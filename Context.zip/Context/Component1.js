import React, { useContext } from "react";
import UserContext from "./UserContext";

function Component1() {
    const user = useContext(UserContext);

  return (
    <>
       
      <h2>{user}</h2>
    </>
  );
}

export default Component1;
